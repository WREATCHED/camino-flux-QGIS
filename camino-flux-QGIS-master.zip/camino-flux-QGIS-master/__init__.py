# (c) Didier  LECLERC 2020 CMSIG MTES-MCTRCT/SG/SNUM/UNI/DRC Site de Rouen
# créé mars 2020 version 1.0

def classFactory(iface):
  from .camino import MainPlugin
  return MainPlugin(iface)